package com.mysampleapp;

import android.app.Fragment;

public class CompleteCartFragment extends Fragment {

}
