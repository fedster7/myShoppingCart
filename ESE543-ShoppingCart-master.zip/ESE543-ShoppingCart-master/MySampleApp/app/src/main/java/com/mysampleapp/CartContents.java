package com.mysampleapp;

import android.content.Context;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


public class CartContents {
    private ArrayList<CartItems> mCart;
    private CartItems c1;   //from freddy down to
    private CartItems c2;
    private CartItems c3;
    private CartItems c4;
    private CartItems c5;
    private CartItems c6;
    private CartItems c7;
    private int i=3;            //here

    private static CartContents sCartContents;
    private Context mAppContext;

    private CartContents(Context appContext) {
        mAppContext = appContext;
        mCart = new ArrayList<CartItems>();
        CartItems c1 = new CartItems("Oreos", "0123456789012", "Rice", 0);
        CartItems c2 = new CartItems("Bannannas", "0123456789013", "Lucky Charms", 0);
        CartItems c3 = new CartItems("Apples", "0123456789014", "Rice Crispies", 0);
        CartItems c4 = new CartItems("Marker_Sharpie", "0123456789015", "Sharpie Red Markers", 0);
        CartItems c5 = new CartItems("Toothpast_CR", "0123456789016", "Crest Toothpaste", 0);
        CartItems c6 = new CartItems("Apple_IPhone", "0123456789017", "Iphone 4S", 0);
        CartItems c7 = new CartItems("Greeting_Card", "0123456789018", "Hallmark Greeting Card", 0);

        //Adding titles to list to display in adapter
       mCart.add(c1);
       mCart.add(c2);
       mCart.add(c3);
       // mCart.add(c4);
       // mCart.add(c5);
       // mCart.add(c6);
       // mCart.add(c7);

    }

    public void setContents (String description, String bar, String name)
    {


        if(i==7)
        {
            i=1;
        }
        if(i==1)
        {
            c1 = new CartItems(name, bar, description, 0);
            mCart.add(c1);

        }
        if(i==2)
        {
            c2 = new CartItems(name, bar, description, 0);
            mCart.add(c2);

        }
        if(i==3)
        {
            c3 = new CartItems(name, bar, description, 0);
            mCart.add(c3);

        }
        if(i==4)
        {
            c4 = new CartItems(name, bar, description, 0);
            mCart.add(c4);

        }
        if(i==5)
        {
            c5 = new CartItems(name, bar, description, 0);
            mCart.add(c5);

        }
        if(i==6)
        {
            c6 = new CartItems(name, bar, description, 0);
            mCart.add(c6);

        }
        if(i==7)
        {
            c7 = new CartItems(name, bar, description, 0);
            mCart.add(c7);

        }
        try {
            TimeUnit.SECONDS.sleep(20);
        }
        catch(Exception e)
        {

        }
        i++;
    }

    public static CartContents get(Context c){
        if (sCartContents == null){
            sCartContents = new CartContents(c.getApplicationContext());
        }
        return sCartContents;
    }

    public ArrayList<CartItems> getCart(){
        return mCart;
    }

}
